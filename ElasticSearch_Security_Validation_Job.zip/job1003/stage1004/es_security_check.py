#!/usr/bin/env python

import sys
import os


elastic_host = '10.91.154.10'
elastic_port = '9200'
endpoint = 'http://' + elastic_host + ':' + elastic_port
import requests
r = requests.get(url = endpoint + '/')
if (r.status_code == 401):
    print 'Test Passed!\nResponse message: %s' % r.content
else:
    print 'Test Failed!'
